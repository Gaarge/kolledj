import os
import hashlib
from datetime import date
from typing import List, Optional

import asyncpg
from fastapi import FastAPI, HTTPException, Query, Response
from pydantic import BaseModel

APP_NAME = "schedule-api"
DATABASE_URL = os.getenv("DATABASE_URL")  # postgresql://user:pass@host:5432/db

app = FastAPI(title=APP_NAME, version="1.0.0")

class ScheduleItem(BaseModel):
    id: int
    date: date
    pair_number: int
    time_start: str
    time_end: str
    subject: str
    session_type: Optional[str] = None
    room: Optional[str] = None
    teacher: Optional[str] = None
    group_name: str

async def get_pool() -> asyncpg.Pool:
    if not hasattr(app.state, "pool"):
        if not DATABASE_URL:
            raise RuntimeError("DATABASE_URL is not configured")
        app.state.pool = await asyncpg.create_pool(dsn=DATABASE_URL, min_size=2, max_size=20)
    return app.state.pool

@app.get("/healthz")
async def healthz():
    return {"status": "ok"}

@app.get("/api/schedule", response_model=List[ScheduleItem])
async def get_schedule(
    response: Response,
    group: str = Query(..., min_length=1, max_length=64),
    date_: str = Query(alias="date", min_length=10, max_length=10)
):
    try:
        y, m, d = int(date_[:4]), int(date_[5:7]), int(date_[8:10])
        _ = date(y, m, d)  # валидация
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid 'date' format, expected YYYY-MM-DD")

    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT id, date, pair_number,
                   to_char(time_start, 'HH24:MI') AS time_start,
                   to_char(time_end, 'HH24:MI') AS time_end,
                   subject, session_type, room, teacher, group_name
            FROM schedule
            WHERE group_name = $1 AND date = $2::date
            ORDER BY pair_number
            """,
            group, date_,
        )
    data = [dict(r) for r in rows]

    payload = str(data).encode("utf-8")
    etag = hashlib.sha1(payload).hexdigest()
    response.headers["Cache-Control"] = "public, max-age=30"
    response.headers["ETag"] = etag

    return data